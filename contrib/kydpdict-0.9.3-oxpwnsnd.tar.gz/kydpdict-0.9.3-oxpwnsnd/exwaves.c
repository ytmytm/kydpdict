#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>
#include <sys/stat.h>
#include <sys/types.h>

#define	BUFLEN		4096
#define NAMELEN		32

/* wave.wol structures */
struct idxhdr
{
	uint32_t	ih_magic;
#define	IH_MAGIC	0x004c4f57 /* "WOL\0" */
	uint32_t	ih_size;
	uint32_t	ih_unknown0;
	uint32_t	ih_nents;
	uint32_t	ih_unknown1;
};

struct idxent
{
	uint32_t	ie_offset; /* item offset in wave.000 */
	uint16_t	ie_unknown0;
	uint16_t	ie_strlen;
	char		*ie_str;
};
/* wave.000 structures */
struct dathdr
{
	uint32_t	dh_magic;
#define	DH_MAGIC	0x00534442
	uint32_t	dh_size;
	uint32_t	dh_unknown0;
	uint32_t	dh_nents;
};

struct datent
{
	uint32_t	de_magic;
#define	DE_MAGIC	0x004d5449
	uint32_t	de_next;
	uint32_t	de_size;
	uint8_t		de_unknown[52];
};

static void
extract(FILE *datfin, struct idxent *idxent)
{
	struct datent datent;
	static uint8_t buf[BUFLEN];
	FILE *fout;
	size_t bytesread = 0;

	fout = fopen(idxent->ie_str, "wb");
	fseek(datfin, idxent->ie_offset, SEEK_SET);
	fread(&datent, sizeof (datent), 1, datfin);

	if (datent.de_magic != DE_MAGIC) {
		printf("Invalid entry.\n");

		exit(EXIT_FAILURE);
	}

	printf("%u\n", datent.de_size);

	while (bytesread < datent.de_size) {
		size_t toread = ((datent.de_size - bytesread) > BUFLEN)
				? BUFLEN
				: (datent.de_size - bytesread);

		bytesread += toread;

		fread(buf, sizeof (buf[0]), toread, datfin);
		fwrite(buf, sizeof (buf[0]), toread, fout);
	}

	fclose(fout);
}

int
main(int argc, char *argv[])
{
	struct idxhdr idxhdr;
	struct dathdr dathdr;
	struct idxent idxent;
	char name[NAMELEN];
	FILE *idxfin;
	FILE *datfin;
	size_t nents = 0;

	if (argc < 3) {
		printf("usage: %s <path-to-wave.wol> <path-to-wave.000>\n", argv[0]);

		return (1);
	}

	idxfin = fopen(argv[1], "rb");
	datfin = fopen(argv[2], "rb");

	if (!idxfin || !datfin) {
		perror("fopen()");

		return (1);
	}

	fread(&idxhdr, sizeof (idxhdr), 1, idxfin);
	fread(&dathdr, sizeof (dathdr), 1, datfin);

	if (idxhdr.ih_magic != IH_MAGIC || dathdr.dh_magic != DH_MAGIC) {
		printf("Invalid file format.\n");

		return (1);
	}

	mkdir("wave", 0733);

	printf("NAME\tOFFSET\n---\n");

	idxent.ie_str = name;

	do {
		if (!fread(&idxent, sizeof (idxent) - sizeof (char*), 1, idxfin))
			break;

		if (!fread(idxent.ie_str, idxent.ie_strlen, 1, idxfin))
			break;

		/* windows patch to *nix path */
		((strchr(idxent.ie_str, '\\'))[0]) = '/';

		printf("%s\t%u\n", idxent.ie_str, idxent.ie_offset);
		extract(datfin, &idxent);

		++nents;
	} while (!feof(idxfin));

	printf("---\n%u\t%u\t%s\n", nents, idxhdr.ih_nents,
		(nents == idxhdr.ih_nents) ? "OK" : "ERROR");

	fclose(idxfin);
	fclose(datfin);

	return (0);
}
